import { Component, OnInit } from "@angular/core";
// ./src/app/product-list/product-list.component.ts
import { ContentfulService } from "./contentful.service";
import { createClient, Entry } from "contentful";
import { RouterModule, Routes, Router } from "@angular/router";
import * as $ from "jquery";
import { AGBsComponent } from "./agbs/agbs.component";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
  inputs: ["language"]
})
export class AppComponent {}
