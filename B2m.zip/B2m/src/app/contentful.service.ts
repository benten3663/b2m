// ./src/app/contentful.service.ts
import { Injectable } from "@angular/core";
// import Contentful createClient and type for `Entry`
import { createClient, Entry, Asset, AssetCollection } from "contentful";
import { config } from "rxjs";

// configure the service with tokens and content type ids
// SET YOU OWN CONFIG here
const CONFIG = {
  // space: 'wl1z0pal05vy',
  // Practiced API
  // space: '7q5uaibpla0z',
  space: "6uxrqosun03b",

  // accessToken: '0e3ec801b5af550c8a1257e8623b1c77ac9b3d8fcfc1b2b7494e3cb77878f92a',

  // accessToken: 'f3e0fe68b462104c6da768b0f64ad10ac9916f2b852167a1ec3fc796617629f6',
  accessToken:
    "c9c3e39f5de4a158daf00eb58762adff20bbfd8ac39a9bc8c90aec10effabed6",

  contentTypeIds: {
    // product: '2PqfXUJwE8qSYKuM0U6w8M'
    // Angular: 'angularExample'
    Home: "mainPage",
    Agbs: "agbs",
    dataProtection: "dataProtection",
    disclaimer: "disclaimer",
    contacts: "contact"
  }
};

@Injectable()
export class ContentfulService {
  private cdaClient = createClient({
    space: CONFIG.space,
    accessToken: CONFIG.accessToken
  });

  constructor() {}

  getProducts(query?: object): Promise<Entry<any>[]> {
    return this.cdaClient
      .getEntries(
        Object.assign(
          {
            content_type: CONFIG.contentTypeIds.Home
          },
          query
        )
      )
      .then(res => res.items);
  }

  getAgbs(query?: object): Promise<Entry<any>[]> {
    return this.cdaClient
      .getEntries(
        Object.assign(
          {
            content_type: CONFIG.contentTypeIds.Agbs
          },
          query
        )
      )
      .then(res => res.items);
  }

  getDataProtection(query?: object): Promise<Entry<any>[]> {
    return this.cdaClient
      .getEntries(
        Object.assign(
          {
            content_type: CONFIG.contentTypeIds.dataProtection
          },
          query
        )
      )
      .then(res => res.items);
  }

  GetContacts(query?: object): Promise<Entry<any>[]> {
    return this.cdaClient
      .getEntries(
        Object.assign(
          {
            content_type: CONFIG.contentTypeIds.contacts
          },
          query
        )
      )
      .then(res => res.items);
  }

  getDisclimer(query?: object): Promise<Entry<any>[]> {
    return this.cdaClient
      .getEntries(
        Object.assign(
          {
            content_type: CONFIG.contentTypeIds.disclaimer
          },
          query
        )
      )
      .then(res => res.items);
  }

  getSpaces(query?: object) {
    // console.log(this.cdaClient.getSpace());
  }

  // client.getAssets()
  // .then(function (assets) {
  //   assets.items.map(function(asset){
  //     var imageURL = 'https:' + asset.fields.file.url;
  //   });
  // })
  // .catch(function (e) {
  //   console.log(e);
  // });

  getassets(query?: object): any {
    return this.cdaClient
      .getAssets(
        Object.assign(
          {
            content_type: CONFIG.contentTypeIds.Home
          },
          query
        )
      )
      .then(res => res.items);
  }

  // getEntries(query?: object): any {
  //   return this.cdaClient
  //     .getEntries(
  //       Object.assign(
  //         {
  //           content_type: CONFIG.contentTypeIds.Home
  //         },
  //         query
  //       )
  //     )
  //     .then(res => res.items);
  // }
}
