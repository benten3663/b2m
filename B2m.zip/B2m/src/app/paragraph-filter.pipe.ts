import { PipeTransform, Pipe } from "@angular/core";
import { ContactComponent } from "./contact/contact.component";

@Pipe({
  name: "paragraphFilter"
})
export class paragraphFilter implements PipeTransform {
  transform(paragraph) {
    console.log(paragraph);

    if (paragraph != null) {
      return paragraph;
    } else {
      return null;
    }
  }
}
