import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AGBsComponent } from './agbs.component';

describe('AGBsComponent', () => {
  let component: AGBsComponent;
  let fixture: ComponentFixture<AGBsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AGBsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AGBsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
