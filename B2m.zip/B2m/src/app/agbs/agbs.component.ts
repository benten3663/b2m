import { Component, OnInit } from "@angular/core";
import { ContentfulService } from "../contentful.service";
import { createClient, Entry } from "contentful";

@Component({
  selector: "app-agbs",
  templateUrl: "./agbs.component.html",
  styleUrls: ["./agbs.component.css"]
})
export class AGBsComponent implements OnInit {
  public AgbsFields: Entry<any>[] = [];
  locale = "";
  CONFIG = {
    space: "6uxrqosun03b",
    accessToken:
      "c9c3e39f5de4a158daf00eb58762adff20bbfd8ac39a9bc8c90aec10effabed6",
    Agbs: "agbs"
  };

  constructor(private contentfulService: ContentfulService) {
    this.vjtry();
  }

  private cdaClient = createClient({
    space: this.CONFIG.space,
    accessToken: this.CONFIG.accessToken
  });

  ngOnInit() {
    this.contentfulService.getAgbs().then(products => {
      this.AgbsFields = products;
      // console.log(products);

      // to set default laguage to German
      // this.updateUI((this.locale = "de"));
    });

    this.contentfulService.getSpaces();
  }

  imagesObject: any = {};
  vjtry() {
    this.cdaClient.getAssets().then(
      assets => {
        assets.items.map(asset => {
          // console.log(asset);

          let imageURL = "https:" + asset.fields.file.url;
          let imageid = asset.sys.id;

          this.imagesObject[imageid] = {
            imageURL: imageURL
          };

          // console.log(this.imagesObject);
        });
      },
      err => {
        console.log(err);
      }
    );
  }

  updateUI(locale = "de") {
    this.cdaClient
      .getEntries({
        "sys.id": "4BDvAksNRKeuQASqwiGqQq",
        locale: locale
      })
      .then(response => {
        let entry = response.items[0];
        // console.log(response);

        // console.log(entry);
        this.renderEntry(entry);
      });
  }

  renderEntry(entry) {
    this.AgbsFields[0] = entry;
    // console.log(this.AgbsFields);
  }
}
