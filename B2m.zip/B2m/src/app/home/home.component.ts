import { Component, OnInit } from "@angular/core";
// ./src/app/product-list/product-list.component.ts
import { ContentfulService } from "../contentful.service";
import { createClient, Entry } from "contentful";
import { RouterModule, Routes, Router } from "@angular/router";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
  inputs: ["language"]
})
export class HomeComponent implements OnInit {
  img: any = "";
  currentTab = "";
  locale = "";

  ParentFields = {
    English: {},
    german: {}
  };

  CONFIG = {
    // space: 'wl1z0pal05vy',
    space: "6uxrqosun03b",
    // accessToken: '0e3ec801b5af550c8a1257e8623b1c77ac9b3d8fcfc1b2b7494e3cb77878f92a',

    // accessToken: 'f3e0fe68b462104c6da768b0f64ad10ac9916f2b852167a1ec3fc796617629f6',

    accessToken:
      "c9c3e39f5de4a158daf00eb58762adff20bbfd8ac39a9bc8c90aec10effabed6",

    contentTypeIds: {
      // product: '2PqfXUJwE8qSYKuM0U6w8M'
      // Angular: 'angularExample'

      Angular: "mainPage"
    }
  };

  // define private class properties
  public products: Entry<any>[] = [];

  private cdaClient = createClient({
    space: this.CONFIG.space,
    accessToken: this.CONFIG.accessToken
  });

  constructor(
    private contentfulService: ContentfulService,
    private router: Router
  ) {
    this.vjtry();
  }

  // fetch data on init
  ngOnInit() {
    this.contentfulService.getProducts().then(products => {
      this.products = products;
      // console.log(products);

      // to set default laguage to German
      // this.updateUI((this.locale = "de"));
    });

    this.contentfulService.getSpaces();
  }

  images: any = [];

  imagesObject: any = {};

  vjtry() {
    this.cdaClient.getAssets().then(
      assets => {
        assets.items.map(asset => {
          // console.log(asset);

          let imageURL = "https:" + asset.fields.file.url;
          let imageid = asset.sys.id;

          this.imagesObject[imageid] = {
            imageURL: imageURL
          };

          // console.log(this.imagesObject);
        });
      },
      err => {
        console.log(err);
      }
    );
  }

  updateUI(locale = "de") {
    this.cdaClient
      .getEntries({
        "sys.id": "1p9ejUBk2csWYsa46IWQQ4",
        locale: locale
      })
      .then(response => {
        let entry = response.items[0];
        // console.log(response);

        // console.log(entry);
        this.renderEntry(entry);
      });
  }

  renderEntry(entry) {
    this.products[0] = entry;
    // console.log(this.products);
  }

  scroll1(el: HTMLElement, tabName) {
    el.scrollIntoView(true);
    window.scrollBy(0, -100);
    this.currentTab = tabName;

    // window.scrollBy({
    //   top: 1000,
    //   behavior: "smooth"
    // });
  }
  scroll2(el: HTMLElement, tabName) {
    el.scrollIntoView(true);
    window.scrollBy(0, -100);
    this.currentTab = tabName;
    // window.scrollBy({
    //   top: 1000,
    //   behavior: "smooth"
    // });
  }
  scroll3(el: HTMLElement, tabName) {
    el.scrollIntoView(true);
    window.scrollBy(0, -100);
    this.currentTab = tabName;
    // window.scrollBy({
    //   top: 1000,
    //   behavior: "smooth"
    // });
  }

  goToContact() {
    window.open(
      "https://preprod-www.b2mobility.com/content/dam/infrastructure/nav-apps/navlite/b2mobility/contact",
      "_blank"
    );
  }
}
