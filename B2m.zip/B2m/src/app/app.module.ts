// ./src/app/app.module.ts
import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AppComponent } from "./app.component";
import { ContentfulService } from "./contentful.service";
import { DisclaimerComponent } from "./disclaimer/disclaimer.component";
import { DataProtectionComponent } from "./data-protection/data-protection.component";
import { AGBsComponent } from "./agbs/agbs.component";
import { HomeComponent } from "./home/home.component";
import { ContactComponent } from "./contact/contact.component";
import { HashLocationStrategy, LocationStrategy } from "@angular/common";
import { paragraphFilter } from "./paragraph-filter.pipe";
// import new component
// import { ProductListComponent } from './product-list/product-list.component';

const routes: Routes = [
  { path: "", pathMatch: "full", redirectTo: "home" },
  // define new component for '/products' route
  //{ path: "", pathMatch: "full", redirectTo: "home" },
  { path: "home", component: HomeComponent },
  { path: "disclaimer", component: DisclaimerComponent },
  { path: "data-protection", component: DataProtectionComponent },
  { path: "agbs", component: AGBsComponent },
  { path: "contact", component: ContactComponent },
  { path: "**", pathMatch: "full", redirectTo: "home" }
];

@NgModule({
  declarations: [
    AppComponent,
    DisclaimerComponent,
    DataProtectionComponent,
    AGBsComponent,
    HomeComponent,
    ContactComponent,
    paragraphFilter
    // add product component
  ],
  imports: [BrowserModule, RouterModule.forRoot(routes, { useHash: true })],
  exports: [],
  providers: [
    ContentfulService,
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
