import { Component, OnInit } from "@angular/core";
import { ContentfulService } from "../contentful.service";
import { createClient, Entry } from "contentful";

@Component({
  selector: "app-contact",
  templateUrl: "./contact.component.html",
  styleUrls: ["./contact.component.css"]
})
export class ContactComponent implements OnInit {
  CONFIG = {
    space: "6uxrqosun03b",
    accessToken:
      "c9c3e39f5de4a158daf00eb58762adff20bbfd8ac39a9bc8c90aec10effabed6",
    dataProtection: "dataProtection"
  };

  public ContactFields: Entry<any>[] = [];
  locale = "";

  private cdaClient = createClient({
    space: this.CONFIG.space,
    accessToken: this.CONFIG.accessToken
  });
  constructor(private contentfulService: ContentfulService) {
    this.vjtry();
  }

  imagesObject: any = {};

  ngOnInit() {
    this.contentfulService.GetContacts().then(products => {
      this.ContactFields = products;
      // console.log(products);

      // to set default laguage to German
      // this.updateUI((this.locale = "de"));
    });
    this.contentfulService.getSpaces();
  }

  vjtry() {
    this.cdaClient.getAssets().then(
      assets => {
        assets.items.map(asset => {
          // console.log(asset);

          let imageURL = "https:" + asset.fields.file.url;
          let imageid = asset.sys.id;

          this.imagesObject[imageid] = {
            imageURL: imageURL
          };

          // console.log(this.imagesObject);
        });
      },
      err => {
        console.log(err);
      }
    );
  }

  updateUI(locale = "de") {
    this.cdaClient
      .getEntries({
        "sys.id": "6jfZV695MkSME8qg4sM4Uy",
        locale: locale
      })
      .then(response => {
        let entry = response.items[0];
        console.log(response);

        console.log(entry);
        this.renderEntry(entry);
      });
  }

  renderEntry(entry) {
    this.ContactFields[0] = entry;
    console.log(this.ContactFields);
  }
}
